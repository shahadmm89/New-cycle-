#!/usr/bin/env node
/**
 * RE-TIME THE FILM AROUND A NEW READ
 * ----------------------------------
 * Swapping the voice changes how long every phrase takes, which breaks the one
 * thing this film depends on: each beat in scenes.ts is pinned to the moment a
 * particular word is said.
 *
 * What survives a voice change is not the absolute times - it is the PACING:
 * how long the narrator waits after each thought. So that is what this stores.
 *
 *   node scripts/plan-timing.mjs --snapshot   capture the approved pacing
 *   node scripts/plan-timing.mjs              show what the current audio implies
 *   node scripts/plan-timing.mjs --write      apply it to src/config/scenes.ts
 *
 * The pauses are measured speech-to-speech, with each clip's own leading and
 * trailing silence taken out, so they mean the same thing whichever engine
 * produced the audio.
 *
 * Beats move with the phrase they belong to. That gets them close; the last
 * word is always a measurement - see docs/EDITING-TEXT-AND-DATES.md on placing
 * a beat from the word onsets inside a clip.
 *
 * PARTIAL READS. A scene can only be re-timed once every one of its phrases has
 * been recorded, because a scene's length is the sum of its clips. Scenes with a
 * phrase still missing are left exactly as they are and reported as such, so the
 * recorded part of a film can be timed properly while the rest is still being
 * made. Run it again when the read is complete.
 */
import fs from 'node:fs';
import path from 'node:path';
import {ROOT, loadConfig, flatVoiceLines} from './lib/config.mjs';
import {readWavInfo} from './lib/wav.mjs';
import {setBeat, sceneBlock} from './lib/scenes-edit.mjs';

const PACING_TS = path.join(ROOT, 'src', 'config', 'voiceover.pacing.ts');
const SCENES_TS = path.join(ROOT, 'src', 'config', 'scenes.ts');
const LINES_DIR = path.join(ROOT, 'assets', 'audio', 'lines');

const snapshot = process.argv.includes('--snapshot');
const write = process.argv.includes('--write');

/**
 * PACE FROM THE PAUSES.
 *
 * A hosted voice speaks at whatever pace it speaks at, and slowing the audio
 * afterwards is what makes a read sound dragged rather than calm. So the words
 * keep their natural rate and the unhurried feeling is recovered from the
 * silence around them instead.
 *
 * --pause-scale 1.5 makes every gap between phrases half again as long. Lead-ins
 * and tails scale too, so a scene still opens and closes at the same rhythm.
 */
const PAUSE_CAP = 1.25;
const pauseScaleArg = process.argv.findIndex((a) => a === '--pause-scale');
const pauseScale = pauseScaleArg >= 0 ? Number(process.argv[pauseScaleArg + 1]) : 1;
if (!Number.isFinite(pauseScale) || pauseScale <= 0) {
  console.error('--pause-scale needs a positive number, e.g. --pause-scale 1.5');
  process.exit(1);
}
/**
 * Longer, but never long enough to read as dead air. The cap applies only
 * BETWEEN phrases: a scene's opening lead-in and closing hold are deliberate
 * and are scaled without one.
 */
const stretch = (gap) => Math.min(PAUSE_CAP, +(gap * pauseScale).toFixed(3));
const scale = (gap) => +(gap * pauseScale).toFixed(3);

const cfg = loadConfig();
const lines = flatVoiceLines(cfg);

/** Leading and trailing silence in one clip, in seconds. */
const silence = (file) => {
  const buf = fs.readFileSync(file);
  const {sampleRate, channels} = readWavInfo(file);
  const data = buf.subarray(buf.indexOf('data') + 8);
  const n = Math.floor(data.length / 2);
  let peak = 0;
  const amp = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const v = Math.abs(data.readInt16LE(i * 2)) / 32768;
    amp[i] = v;
    if (v > peak) peak = v;
  }
  const thr = Math.max(peak * 0.02, 0.004);
  let first = 0;
  let last = n - 1;
  while (first < n && amp[first] <= thr) first++;
  while (last > first && amp[last] <= thr) last--;
  const rate = sampleRate * channels;
  return {lead: first / rate, tail: (n - 1 - last) / rate, duration: n / rate};
};

const clips = {};
const unrecorded = [];
for (const l of lines) {
  const f = path.join(LINES_DIR, `${l.id}.wav`);
  if (!fs.existsSync(f)) {
    unrecorded.push(l.id);
    continue;
  }
  clips[l.id] = silence(f);
}
/** A scene can only be re-timed when all of its phrases have been recorded. */
const measured = (sceneId) =>
  lines.filter((l) => l.sceneId === sceneId).every((l) => clips[l.id]);

if (unrecorded.length) {
  const scenes = cfg.scenes.filter((s) => s.voice.length && !measured(s.id)).map((s) => s.id);
  console.log(
    `! ${unrecorded.length} phrase(s) not recorded yet: ${unrecorded.join(' ')}\n` +
      `  Leaving these scenes as they are: ${scenes.join(' ')}\n`,
  );
  if (snapshot) {
    console.error('--snapshot needs the whole read; it describes the film as a whole.');
    process.exit(1);
  }
}

/** Where the first and last WORD of a line sit, absolutely. */
const speechStart = (l) => l.absoluteStart + clips[l.id].lead;
const speechEnd = (l) => l.absoluteStart + clips[l.id].duration - clips[l.id].tail;

// --- capture -------------------------------------------------------------
if (snapshot) {
  const perScene = cfg.scenes.map((s, i) => {
    const start = cfg.sceneStarts[i];
    const own = lines.filter((l) => l.sceneId === s.id);
    if (!own.length) return {id: s.id, silent: true, duration: s.duration};
    const pauses = own.slice(0, -1).map((l, k) => +(speechStart(own[k + 1]) - speechEnd(l)).toFixed(3));
    return {
      id: s.id,
      leadIn: +(speechStart(own[0]) - start).toFixed(3),
      pauses,
      tail: +(start + s.duration - speechEnd(own[own.length - 1])).toFixed(3),
    };
  });
  fs.writeFileSync(
    PACING_TS,
    `/**
 * THE APPROVED PACING, in seconds of real silence.
 *
 * Auto-generated by \`npm run voiceover:plan -- --snapshot\` from the approved
 * cut. These are the numbers that should survive a voice change: how long the
 * narrator waits before starting a scene, between thoughts inside it, and
 * before the scene ends.
 *
 * They are measured speech-to-speech - each clip's own leading and trailing
 * silence is excluded - so they mean the same thing whichever engine produced
 * the audio.
 *
 * A scene marked \`silent\` has no narration; its duration is kept as-is.
 */
export interface ScenePacing {
  id: string;
  /** Scene start -> first word. */
  leadIn?: number;
  /** Silence between consecutive phrases, in order. */
  pauses?: number[];
  /** Last word -> scene end. */
  tail?: number;
  silent?: boolean;
  duration?: number;
}

export const pacing: ScenePacing[] = ${JSON.stringify(perScene, null, 2)};
`,
  );
  console.log(`> wrote ${path.relative(ROOT, PACING_TS)}`);
  for (const p of perScene) {
    console.log(
      p.silent
        ? `  ${p.id.padEnd(11)} silent, ${p.duration}s`
        : `  ${p.id.padEnd(11)} lead ${p.leadIn.toFixed(2)}  pauses [${p.pauses.map((x) => x.toFixed(2)).join(', ')}]  tail ${p.tail.toFixed(2)}`,
    );
  }
  process.exit(0);
}

// --- re-derive -----------------------------------------------------------
if (!fs.existsSync(PACING_TS)) {
  console.error(
    `No pacing snapshot yet.\n` +
      `  Run this once against the approved audio to capture it:\n` +
      `    npm run voiceover:plan -- --snapshot`,
  );
  process.exit(1);
}
const {pacing} = await import(`file://${path.join(ROOT, '.cache', 'config', 'config', 'voiceover.pacing.js')}`)
  .catch(async () => {
    // The shared compile step does not know about this file, so read it plainly.
    const src = fs.readFileSync(PACING_TS, 'utf8');
    const json = src.slice(src.indexOf('= ', src.indexOf('export const pacing')) + 2, src.lastIndexOf(';'));
    return {pacing: JSON.parse(json)};
  });

const plan = [];
let cursor = 0;
for (const scene of cfg.scenes) {
  const pace = pacing.find((p) => p.id === scene.id);
  if (!pace) throw new Error(`No pacing entry for scene "${scene.id}". Re-run --snapshot.`);
  const own = lines.filter((l) => l.sceneId === scene.id);

  if (pace.silent || !own.length || !measured(scene.id)) {
    plan.push({
      id: scene.id,
      duration: scene.duration,
      starts: {},
      start: cursor,
      held: own.length > 0 && !measured(scene.id),
    });
    cursor += scene.duration;
    continue;
  }

  const starts = {};
  // First word lands leadIn after the scene opens; the clip's own lead silence
  // has to be taken off, because that silence is part of the file.
  let t = scale(pace.leadIn) - clips[own[0].id].lead;
  for (let k = 0; k < own.length; k++) {
    const c = clips[own[k].id];
    starts[own[k].id] = +t.toFixed(2);
    if (k < own.length - 1) {
      const gap = stretch(pace.pauses[k] ?? 0.45);
      t += c.duration - c.tail + gap - clips[own[k + 1].id].lead;
    } else {
      t += c.duration - c.tail + scale(pace.tail);
    }
  }
  plan.push({id: scene.id, duration: +t.toFixed(2), starts, start: cursor});
  cursor += +t.toFixed(2);
}

let changed = 0;
console.log('scene        duration          lines');
for (const p of plan) {
  const scene = cfg.scenes.find((s) => s.id === p.id);
  const dd = +(p.duration - scene.duration).toFixed(2);
  if (dd !== 0) changed++;
  const moves = Object.entries(p.starts)
    .map(([id, st]) => {
      const was = scene.voice.find((v) => v.id === id).start;
      const d = +(st - was).toFixed(2);
      if (d !== 0) changed++;
      return `${id} ${st.toFixed(2)}${d ? ` (${d > 0 ? '+' : ''}${d})` : ''}`;
    })
    .join('  ');
  console.log(
    `${p.id.padEnd(11)} ${p.duration.toFixed(2).padStart(6)}` +
      `${dd ? ` (${dd > 0 ? '+' : ''}${dd})`.padEnd(10) : ''.padEnd(10)} ` +
      `${p.held ? 'not recorded yet - left alone' : moves}`,
  );
}
console.log(`\ntotal ${cursor.toFixed(2)}s (was ${cfg.totalDuration.toFixed(2)}s)`);

// What the read actually sounds like, so the pause scale can be judged rather
// than guessed at.
// Both figures describe the audio that exists, so unrecorded phrases are left
// out of each rather than counted as zero seconds of very fast speech.
const recorded = lines.filter((l) => clips[l.id]);
const words = recorded.reduce((n, l) => n + (l.spoken ?? l.text).split(/\s+/).length, 0);
const speech = recorded.reduce((t, l) => t + clips[l.id].duration - clips[l.id].lead - clips[l.id].tail, 0);
const gaps = [];
for (const p of plan) {
  if (p.held) continue;
  const own = lines.filter((l) => l.sceneId === p.id);
  for (let k = 0; k < own.length - 1; k++) {
    const a = own[k];
    const b = own[k + 1];
    gaps.push(p.starts[b.id] + clips[b.id].lead - (p.starts[a.id] + clips[a.id].duration - clips[a.id].tail));
  }
}
gaps.sort((x, y) => x - y);
console.log(
  `word rate ${((words / speech) * 60).toFixed(0)} wpm (unchanged - the words are never slowed)` +
    `${recorded.length < lines.length ? `, over the ${recorded.length} recorded phrases` : ''}\n` +
    (gaps.length
      ? `pauses between phrases: median ${gaps[Math.floor(gaps.length / 2)].toFixed(2)}s, ` +
        `longest ${gaps[gaps.length - 1].toFixed(2)}s` +
        (pauseScale === 1 ? '' : `  [--pause-scale ${pauseScale}, capped at ${PAUSE_CAP}s]`)
      : 'no scene is fully recorded yet, so there is nothing to re-time'),
);

if (!changed) {
  console.log('\nNothing to change - the audio already matches the approved pacing.');
  process.exit(0);
}

if (!write) {
  console.log('\nRe-run with --write to apply this to src/config/scenes.ts.');
  process.exit(0);
}

// --- apply ---------------------------------------------------------------
let src = fs.readFileSync(SCENES_TS, 'utf8');
const beatNotes = [];
for (const p of plan) {
  const scene = cfg.scenes.find((s) => s.id === p.id);
  const [from, to] = sceneBlock(src, p.id);
  let block = src.slice(from, to);

  block = block.replace(/duration: [0-9.]+,/, `duration: ${p.duration},`);

  for (const [id, st] of Object.entries(p.starts)) {
    const re = new RegExp(`(id: '${id}',\\n\\s+start: )[0-9.]+,`);
    block = block.replace(re, `$1${st},`);
  }

  // A beat belongs to whichever phrase was being spoken when it fired, so it
  // moves by that phrase's delta.
  const own = scene.voice;
  if (own.length) {
    for (const [beat, at] of Object.entries(scene.beats)) {
      let owner = own[0];
      for (const l of own) if (l.start <= at + 0.001) owner = l;
      const delta = +(p.starts[owner.id] - owner.start).toFixed(2);
      if (!delta) continue;
      const moved = +Math.max(0, at + delta).toFixed(2);
      // Throws rather than no-ops if the beat is not found, whichever layout
      // the scene uses for its beats object.
      block = setBeat(block, p.id, beat, moved);
      beatNotes.push(`${p.id}.${beat} ${at} -> ${moved} (with ${owner.id})`);
    }
  }
  src = src.slice(0, from) + block + src.slice(to);
}
fs.writeFileSync(SCENES_TS, src);
console.log(`\n> updated ${path.relative(ROOT, SCENES_TS)}`);
if (beatNotes.length) {
  console.log('> beats moved with their phrase:');
  for (const n of beatNotes) console.log(`    ${n}`);
  console.log(
    '\n  These are first approximations. Check each against the word it is meant to\n' +
      '  land on - docs/EDITING-TEXT-AND-DATES.md explains how to read the onsets\n' +
      '  out of assets/audio/lines/<line-id>.wav.',
  );
}
console.log('\nNow: npm run voiceover:build -- --assemble-only && npm run captions && npm run render');
